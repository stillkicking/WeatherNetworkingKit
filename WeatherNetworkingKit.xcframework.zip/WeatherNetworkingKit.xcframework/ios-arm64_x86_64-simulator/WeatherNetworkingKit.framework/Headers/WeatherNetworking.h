//
//  WeatherNetworking.h
//  WeatherNetworking
//
//  Created by jonathan saville on 18/10/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for WeatherNetworking.
FOUNDATION_EXPORT double WeatherNetworkingVersionNumber;

//! Project version string for WeatherNetworking.
FOUNDATION_EXPORT const unsigned char WeatherNetworkingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeatherNetworking/PublicHeader.h>


